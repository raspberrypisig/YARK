package Client;

public class NavHeading {

    public float Pitch, Heading;

    NavHeading() {
        Pitch = Heading = 0;
    }

    NavHeading(float pitch, float heading) {
        Pitch = pitch;
        Heading = heading;
    }
}
