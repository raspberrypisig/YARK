# YARK
Yet Another Remote Controler

Plugin for Kerbal Space Program that allows for remote control and data monitoring of vessels. Comes with c++ and java client.

More information avaliable here: https://forum.kerbalspaceprogram.com/index.php?/topic/176833-yet-another-remote-kontroller\
